#!/bin/bash 
#stage('Docker Build & Push')
docker build -t .
